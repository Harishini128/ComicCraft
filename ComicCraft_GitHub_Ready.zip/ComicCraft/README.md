# ComicCraft - AI Comic Story Creator using Gemini

A FastAPI + Jinja2 web application for generating personalized 5-panel comic stories with Google's Gemini model and exporting the result as a PDF.

## Features
- Story prompt, character, setting, tone and art-style inputs
- Gemini-powered 5-panel comic outline, narration and dialogue
- Comic preview page
- PDF export
- JSON API endpoint
- FastAPI `/docs` API documentation

## Architecture
Frontend: HTML/CSS/Jinja2
Backend: FastAPI
AI: Google Gemini
Export: FPDF

The TN Skill project specification also describes Stable Diffusion/Hugging Face Diffusers for comic illustrations. This repository keeps image generation modular so that Stable Diffusion can be added with Hugging Face credentials when required.

## Run locally
```bash
python -m venv env
# Windows
.\\env\\Scripts\\activate
# macOS/Linux
source env/bin/activate
pip install -r requirements.txt
```

Copy `.env.example` to `.env` and add your Gemini API key.

```bash
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000` and `http://127.0.0.1:8000/docs`.

## GitHub
Do not upload `.env` or API keys. Upload the project folder and keep `.env.example` in the repository.
