import os, json
from dotenv import load_dotenv
from google import genai

load_dotenv()
API_KEY = os.getenv('GEMINI_API_KEY')


def generate_comic(story_prompt, character_name, setting, tone, art_style):
    if not API_KEY:
        raise RuntimeError('GEMINI_API_KEY is missing. Copy .env.example to .env and add your API key.')
    client = genai.Client(api_key=API_KEY)
    prompt = f'''Create a 5-panel comic story as valid JSON only.
Story idea: {story_prompt}
Main character: {character_name}
Setting: {setting}
Tone: {tone}
Art style: {art_style}

Return exactly an object with a panels array. Each panel must contain:
panel_number, title, scene_description, image_prompt, caption, narration, dialogue.
Make the five panels coherent and keep dialogue concise.'''
    response = client.models.generate_content(model='gemini-2.5-flash', contents=prompt)
    text = response.text.strip().replace('```json', '').replace('```', '').strip()
    return json.loads(text)['panels']
