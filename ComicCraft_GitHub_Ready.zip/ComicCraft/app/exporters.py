import os
from datetime import datetime
from fpdf import FPDF

def save_pdf(panels):
    os.makedirs('static/exports', exist_ok=True)
    filename = f"comiccraft_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    path = os.path.join('static/exports', filename)
    pdf = FPDF()
    for panel in panels:
        pdf.add_page()
        pdf.set_font('Helvetica', 'B', 18)
        pdf.multi_cell(0, 10, f"Panel {panel.get('panel_number', '')}: {panel.get('title', '')}")
        pdf.ln(8)
        pdf.set_font('Helvetica', 'I', 11)
        pdf.multi_cell(0, 7, panel.get('scene_description', ''))
        pdf.ln(4)
        pdf.set_font('Helvetica', '', 12)
        for label in ('caption', 'narration', 'dialogue'):
            pdf.multi_cell(0, 7, f"{label.title()}: {panel.get(label, '')}")
            pdf.ln(2)
    pdf.output(path)
    return '/' + path
