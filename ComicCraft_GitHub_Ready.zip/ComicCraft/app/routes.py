from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from app.gemini import generate_comic
from app.exporters import save_pdf

router = APIRouter()

class PromptRequest(BaseModel):
    story_prompt: str
    character_name: str
    setting: str
    tone: str
    art_style: str

def render(request, template, **context):
    from app.main import templates
    return templates.TemplateResponse(template, {'request': request, **context})

@router.get('/', response_class=HTMLResponse)
async def home(request: Request):
    return render(request, 'index.html')

@router.post('/generate', response_class=HTMLResponse)
async def generate(request: Request, story_prompt: str = Form(...), character_name: str = Form(...), setting: str = Form(...), tone: str = Form(...), art_style: str = Form(...)):
    try:
        panels = generate_comic(story_prompt, character_name, setting, tone, art_style)
        pdf_path = save_pdf(panels)
        return render(request, 'comic_preview.html', panels=panels, pdf_path=pdf_path)
    except Exception as e:
        return render(request, 'index.html', error=str(e))

@router.post('/generate-comic/json')
async def generate_json(data: PromptRequest):
    panels = generate_comic(data.story_prompt, data.character_name, data.setting, data.tone, data.art_style)
    pdf_path = save_pdf(panels)
    return {'panels': panels, 'pdf_path': pdf_path}

@router.get('/export-success', response_class=HTMLResponse)
async def export_success(request: Request):
    return render(request, 'export_success.html')
